# Excercise files: 

Open the below files to continue with this excercise: 

- [check_images.py](../data/check_images.py)

from time import time, sleep
def main():
    # TODO: 0 Add your code below to measure total program runtime
        start_time = time()
            
                # Your code to execute goes here
                    
                        # Example of sleep to simulate program execution time
                            sleep(75)  # Replace this with your actual code
                                
                                    # Calculate total runtime
                                        end_time = time()
                                            tot_time = end_time - start_time
                                                
                                                    # Format total runtime into hh:mm:ss
                                                        hours = int(tot_time / 3600)
                                                            minutes = int((tot_time % 3600) / 60)
                                                                seconds = int((tot_time % 3600) % 60)
                                                                    
                                                                        # Print total elapsed runtime
                                                                            print("\nTotal Elapsed Runtime:", str(hours) + ":" + str(minutes) + ":" + str(seconds))
                                                                            